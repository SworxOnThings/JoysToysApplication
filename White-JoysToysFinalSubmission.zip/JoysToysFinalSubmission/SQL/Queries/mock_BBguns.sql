/*
INSERT INTO products(product_id, product_name, price, product_stock, imageurl, category)
values(DEFAULT, 'Bushmaster BMPX-Full Auto BB gun', 65.00, 10, 'http://localhost/JoysToysImages/BBGuns/bushmasterbmpwxfullauto.jpg', 4);

INSERT INTO products(product_id, product_name, price, product_stock, imageurl, category)
values(DEFAULT, 'Crosman MK45 BB gun', 45.00, 10, 'http://localhost/JoysToysImages/BBGuns/crosmanmk45.jpg', 4);

INSERT INTO products(product_id, product_name, price, product_stock, imageurl, category)
values(DEFAULT, 'DPMS Full Auto BB gun', 105.00, 10, 'http://localhost/JoysToysImages/BBGuns/dpmsfullautobbgun.jpg', 4);

INSERT INTO products(product_id, product_name, price, product_stock, imageurl, category)
values(DEFAULT, 'Glock Gen 3 BB gun', 35.00, 10, 'http://localhost/JoysToysImages/BBGuns/glockgen3bbgun.jpg', 4);

INSERT INTO products(product_id, product_name, price, product_stock, imageurl, category)
values(DEFAULT, 'Umarex DX17 BB gun', 60.00, 10, 'http://localhost/JoysToysImages/BBGuns/umarexdx17bbgun.jpg', 4);
*/

SELECT * FROM products;