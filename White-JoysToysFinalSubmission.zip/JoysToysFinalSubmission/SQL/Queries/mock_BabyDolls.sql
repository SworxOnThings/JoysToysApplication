
--INSERT INTO products(product_id, product_name, price, product_stock, imageurl, category)
--values(DEFAULT, 'Adora Soft Baby Doll - machine washable', 15.00, 10, 'http://localhost/JoysToysImages/BabyDolls/adorasoftbabydoll-machinewashable.jpg', 3);

--INSERT INTO products(product_id, product_name, price, product_stock, imageurl, category)
--values(DEFAULT, 'Twin Baby Doll set', 24.00, 10, 'http://localhost/JoysToysImages/BabyDolls/twinbabydolls.jpg', 3);


SELECT * FROM products;