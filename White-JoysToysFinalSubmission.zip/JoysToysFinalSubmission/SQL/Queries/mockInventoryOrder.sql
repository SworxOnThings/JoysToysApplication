/*
INSERT INTO inventory_order values(DEFAULT, now(), 100, 1, 1);
*/
select * from inventory_order;