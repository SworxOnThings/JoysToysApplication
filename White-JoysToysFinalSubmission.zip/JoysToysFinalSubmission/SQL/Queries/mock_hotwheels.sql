/*
INSERT INTO products(product_id, product_name, price, product_stock, imageurl, category)
values(DEFAULT, 'Hot Wheels 50 car pack', 25.00, 10, 'http://localhost/JoysToysImages/HotWheels/hotwheels50carpack.jpg', 5);

INSERT INTO products(product_id, product_name, price, product_stock, imageurl, category)
values(DEFAULT, 'Hot Wheels Massive Loop Launcher', 34.00, 10, 'http://localhost/JoysToysImages/HotWheels/hotwheelsmassivelooplauncher.jpg', 5);

INSERT INTO products(product_id, product_name, price, product_stock, imageurl, category)
values(DEFAULT, 'Hot Wheels 4 Way Intersection Crash track', 15.00, 10, 'http://localhost/JoysToysImages/HotWheels/hotwheelstrack4wayintersection.jpg', 5);
*/

SELECT * FROM products;
