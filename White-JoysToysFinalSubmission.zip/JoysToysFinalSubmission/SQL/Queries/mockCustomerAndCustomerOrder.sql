/*
INSERT INTO Customer(customer_id, name, email, address, phonenumber) values(DEFAULT, 'Sam', 'none@none.com', '123 nowhere st', 334-399-2054);
INSERT INTO Customer_Order(customer_order_id, customer_order_date, customer_id) 
values(DEFAULT, now(), 1);
*/

select * from customer_order;