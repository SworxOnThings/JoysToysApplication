/*
INSERT INTO restocking_logistics values(DEFAULT, 1, 1, 10);
*/
select * from restocking_logistics;