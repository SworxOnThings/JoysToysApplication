/*
INSERT INTO products(product_id, product_name, price, product_stock, imageurl, category)
values(DEFAULT, 'Aluminum Baseball Bat', 15.00, 10, 'http://localhost/JoysToysImages/Sports/aluminumbat.jpg', 6);

INSERT INTO products(product_id, product_name, price, product_stock, imageurl, category)
values(DEFAULT, 'Beechwood Baseball Bat', 29.00, 10, 'http://localhost/JoysToysImages/Sports/beechwoodbat.jpg', 6);

INSERT INTO products(product_id, product_name, price, product_stock, imageurl, category)
values(DEFAULT, 'Franklin Junior Football', 9.00, 10, 'http://localhost/JoysToysImages/Sports/Franklin-JuniorFootball.jpg', 6);

INSERT INTO products(product_id, product_name, price, product_stock, imageurl, category)
values(DEFAULT, 'Hit Run Steal Bucket of Baseballs', 40.00, 10, 'http://localhost/JoysToysImages/Sports/hitrunstealbucketofbaseballs.jpg', 6);

INSERT INTO products(product_id, product_name, price, product_stock, imageurl, category)
values(DEFAULT, 'Pecogo Volleyball', 5.00, 10, 'http://localhost/JoysToysImages/Sports/pecogo-volleyball.jpg', 6);

INSERT INTO products(product_id, product_name, price, product_stock, imageurl, category)
values(DEFAULT, 'Rawlings Baseball Gloves', 11.00, 10, 'http://localhost/JoysToysImages/Sports/rawlings-baseballglove.jpg', 6);

INSERT INTO products(product_id, product_name, price, product_stock, imageurl, category)
values(DEFAULT, 'Tachikara Volleyball', 5.00, 10, 'http://localhost/JoysToysImages/Sports/tachikara-volleyball.jpg', 6);

INSERT INTO products(product_id, product_name, price, product_stock, imageurl, category)
values(DEFAULT, 'Wilson Evolution Basketball', 25.00, 10, 'http://localhost/JoysToysImages/Sports/wilson-evolutionbasketball.jpg', 6);

INSERT INTO products(product_id, product_name, price, product_stock, imageurl, category)
values(DEFAULT, 'Wilson NCAA Indoor/Outdoor Basketball', 20.00, 10, 'http://localhost/JoysToysImages/Sports/wilson-ncaaindooroutdoorbasketball.jpg', 6);

INSERT INTO products(product_id, product_name, price, product_stock, imageurl, category)
values(DEFAULT, 'Wilson NFL Football', 9.00, 10, 'http://localhost/JoysToysImages/Sports/wilsonnflfootball.jpg', 6);
*/

select * from products;
