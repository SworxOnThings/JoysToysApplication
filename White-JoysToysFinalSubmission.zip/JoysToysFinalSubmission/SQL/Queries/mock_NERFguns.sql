/*
INSERT INTO products(product_id, product_name, price, product_stock, imageurl, category)
values(DEFAULT, 'NERF Fortnite BASR-L', 45.00, 10, 'http://localhost/JoysToysImages/NerfGuns/nerffortniteBASR-L.jpg', 4);

INSERT INTO products(product_id, product_name, price, product_stock, imageurl, category)
values(DEFAULT, 'NERF Micro Shots - 6 blaster bundle', 75.00, 10, 'http://localhost/JoysToysImages/NerfGuns/nerfmicroshots-6blasterbundle.jpg', 4);

INSERT INTO products(product_id, product_name, price, product_stock, imageurl, category)
values(DEFAULT, 'NERF Rival Nemesis', 105.00, 10, 'http://localhost/JoysToysImages/NerfGuns/nerfrivalnemesis.jpg', 4);

INSERT INTO products(product_id, product_name, price, product_stock, imageurl, category)
values(DEFAULT, 'Seymour Toy Guns - Automatic Sniper Rifle', 40.00, 10, 'http://localhost/JoysToysImages/NerfGuns/semourtoyguns-automaticsniperrifle.jpg', 4);
*/

SELECT * FROM products;