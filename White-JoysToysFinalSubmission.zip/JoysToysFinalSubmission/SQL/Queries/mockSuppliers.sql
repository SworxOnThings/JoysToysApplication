/*
INSERT INTO suppliers values
(DEFAULT, 'Hasbro', '555 plastic road, Buena Vista, CA', '315-555-0044', 'none@hasbro.com');
*/
select * from suppliers;