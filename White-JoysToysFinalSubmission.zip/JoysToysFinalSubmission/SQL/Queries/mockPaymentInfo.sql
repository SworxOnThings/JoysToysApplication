/*
INSERT INTO payment_information 
(payment_information_id, credit_card_number, kind, customer_id) 
values (DEFAULT, '1234-5678-9090-8989', 1, 1);
*/
select * from payment_information;