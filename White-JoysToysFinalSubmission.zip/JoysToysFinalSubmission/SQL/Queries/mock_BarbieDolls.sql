/*
INSERT INTO products(product_id, product_name, price, product_stock)
values(DEFAULT, 'Barbie Fantasy Hair Doll', 16.00, 10);
INSERT INTO products(product_id, product_name, price, product_stock)
values(DEFAULT, 'Barbie Stroller Pups', 7.00, 10);
INSERT INTO products(product_id, product_name, price, product_stock)
values(DEFAULT, 'Sparkling Pink Barbie Doll', 3.00, 10);
*/

--UPDATE products SET imageurl='http://localhost/JoysToysImages/BarbieDolls/barbiefantasyhairdoll.jpg', 
--category=2 where product_id=5;

--UPDATE products SET imageurl='http://localhost/JoysToysImages/BarbieDolls/barbiestrollerpups.jpg', 
--category=2 where product_id=6;

--UPDATE products SET imageurl='http://localhost/JoysToysImages/BarbieDolls/sparklingpinkbarbie.jpg', 
--category=2 where product_id=7;

SELECT * FROM products;