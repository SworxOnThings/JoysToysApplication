ALTER SEQUENCE categories_category_id_seq RESTART WITH 1;

ALTER SEQUENCE customer_customer_id_seq RESTART WITH 1;

ALTER SEQUENCE customer_order_customer_order_id_seq RESTART WITH 1;

ALTER SEQUENCE customer_transactions_customer_transaction_id_seq RESTART WITH 1;

ALTER SEQUENCE delivery_delivery_id_seq RESTART WITH 1;

ALTER SEQUENCE employee_employee_id_seq RESTART WITH 1;

ALTER SEQUENCE inventory_order_inventory_order_id_seq RESTART WITH 1;

ALTER SEQUENCE inventory_transactions_transaction_id_seq RESTART WITH 1;

ALTER SEQUENCE job_role_job_id_seq RESTART WITH 1;

ALTER SEQUENCE products_product_id_seq RESTART WITH 1;

ALTER SEQUENCE suppliers_supplier_id_seq RESTART WITH 1;

ALTER SEQUENCE restocking_logistics_restocking_logistics_id_seq RESTART WITH 1;