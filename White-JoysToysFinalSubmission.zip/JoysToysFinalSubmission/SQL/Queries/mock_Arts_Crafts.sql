/*
INSERT INTO products(product_id, product_name, price, product_stock, imageurl, category)
values(DEFAULT, 'Air Dry Clay 36 colors', 20.00, 10, 'http://localhost/JoysToysImages/Arts_Crafts/airdryclay-36colors.jpg', 7);

INSERT INTO products(product_id, product_name, price, product_stock, imageurl, category)
values(DEFAULT, 'Coloring & Tracing Animals', 6.00, 10, 'http://localhost/JoysToysImages/Arts_Crafts/animals-coloringandtracing.jpg', 7);

INSERT INTO products(product_id, product_name, price, product_stock, imageurl, category)
values(DEFAULT, 'Big Letter Tracing Book forToddlers', 7.00, 10, 'http://localhost/JoysToysImages/Arts_Crafts/biglettertracingbookfortoddlers.jpg', 7);

INSERT INTO products(product_id, product_name, price, product_stock, imageurl, category)
values(DEFAULT, 'Gem Art 50Gems', 3.00, 10, 'http://localhost/JoysToysImages/Arts_Crafts/gemart-5dgems.jpg', 7);

INSERT INTO products(product_id, product_name, price, product_stock, imageurl, category)
values(DEFAULT, 'Glow In The Dark Rock Painting', 15.00, 10, 'http://localhost/JoysToysImages/Arts_Crafts/glowinthedarkrockpainting.jpg', 7);

INSERT INTO products(product_id, product_name, price, product_stock, imageurl, category)
values(DEFAULT, 'Halloween Trace & Color', 5.00, 10, 'http://localhost/JoysToysImages/Arts_Crafts/halloween-traceandcolor.jpg', 7);

INSERT INTO products(product_id, product_name, price, product_stock, imageurl, category)
values(DEFAULT, 'How to draw Anime', 5.00, 10, 'http://localhost/JoysToysImages/Arts_Crafts/howtodrawanime.jpg', 7);

INSERT INTO products(product_id, product_name, price, product_stock, imageurl, category)
values(DEFAULT, 'How to Draw Superheroes', 5.00, 10, 'http://localhost/JoysToysImages/Arts_Crafts/howtodrawsuperheroes.jpg', 7);

INSERT INTO products(product_id, product_name, price, product_stock, imageurl, category)
values(DEFAULT, 'iBayam 50 pack wooden art set', 25.00, 10, 'http://localhost/JoysToysImages/Arts_Crafts/ibayam-150packwoodenartset.jpg', 7);

INSERT INTO products(product_id, product_name, price, product_stock, imageurl, category)
values(DEFAULT, 'Trace and escape - tracing book', 5.00, 10, 'http://localhost/JoysToysImages/Arts_Crafts/traceandescape.jpg', 7);

INSERT INTO products(product_id, product_name, price, product_stock, imageurl, category)
values(DEFAULT, 'Tracing Lines, Shapes, and Words - Preschool', 4.00, 10, 'http://localhost/JoysToysImages/Arts_Crafts/tracinglinesshapesandwords-preschool.jpg', 7);

INSERT INTO products(product_id, product_name, price, product_stock, imageurl, category)
values(DEFAULT, 'Tracing Paper', 2.00, 10, 'http://localhost/JoysToysImages/Arts_Crafts/tracingpaper.jpg', 7);
*/

SELECT * FROM products;
