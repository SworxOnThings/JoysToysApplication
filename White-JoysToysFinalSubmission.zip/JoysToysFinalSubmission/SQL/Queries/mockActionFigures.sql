/*
INSERT INTO products(product_id, product_name, price, product_stock, category)
values(DEFAULT, 'goku_action_figure', 9.00, 10, 1);
INSERT INTO products(product_id, product_name, price, product_stock, category)
values(DEFAULT, 'MonkeyDLuffe', 9.00, 10, 1);
INSERT INTO products(product_id, product_name, price, product_stock, category)
values(DEFAULT, 'neoson24pcspokeballs', 30.00, 5, 1);
INSERT INTO products(product_id, product_name, price, product_stock, category)
values(DEFAULT, 'Spider-man_TitanSeries', 7.50, 15, 1);
*/

--UPDATE products SET imageurl='http://localhost:80/JoysToysImages/ActionFigures/gokuActionFigure.jpg' where product_id=1;

--UPDATE products SET imageurl='http://localhost:80/JoysToysImages/ActionFigures/monkeydluffeactionfigure.jpg' where product_id=2;

--UPDATE products SET imageurl='http://localhost:80/JoysToysImages/ActionFigures/neoson24pcspokeballs.jpg' where product_id=3;

--UPDATE products SET imageurl='http://localhost:80/JoysToysImages/ActionFigures/titanSpiderman.jpg' where product_id=4;

SELECT * FROM products;