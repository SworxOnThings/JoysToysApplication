/*
INSERT INTO customer_order_product_association
(customer_order_product_association_id, customer_order_id, product_id, quantity)
values(DEFAULT, 1, 1, 2);


INSERT INTO customer_order_product_association
(customer_order_product_association_id, customer_order_id, product_id, quantity)
values(DEFAULT, DEFAULT, 3, 5);
*/

--select * from products;
--select * from customer_order_product_association;
--select * from customer_order;