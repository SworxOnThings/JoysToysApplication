/*
INSERT INTO categories(category_id, category_name) values(DEFAULT, 'Action_Figures');
INSERT INTO categories(category_id, category_name) values(DEFAULT, 'Barbie_Dolls');
INSERT INTO categories(category_id, category_name) values(DEFAULT, 'Baby_Dolls');
INSERT INTO categories(category_id, category_name) values(DEFAULT, 'Toy_Guns');
INSERT INTO categories(category_id, category_name) values(DEFAULT, 'Toy_Cars');
INSERT INTO categories(category_id, category_name) values(DEFAULT, 'Sports');
INSERT INTO categories(category_id, category_name) values(DEFAULT, 'Arts&Crafts');
SELECT * FROM categories;
*/