import ShoppingList from "../components/ShoppingList"

export default function Checkout(){

    return(
        <>
            <ShoppingList />
            <div>
                add address and add payments
            </div>
        </>
    )

}