package com.JoysToysApplication.JoysToysApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JoysToysApplicationTests {

	@Test
	void contextLoads() {
	}

}
