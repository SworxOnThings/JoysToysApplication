package com.joystoys.JoysToysBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JoysToysBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
