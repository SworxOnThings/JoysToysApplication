package com.joystoys.JoysToysBackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JoysToysBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(JoysToysBackendApplication.class, args);
	}

}
